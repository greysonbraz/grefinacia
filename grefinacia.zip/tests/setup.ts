import 'fake-indexeddb/auto';
